﻿using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Data
/// </summary>
public class Data:System.Web.UI.Page
{
    SqlConnection cn;
    public Data()
    {
        string strcn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='"+Server.MapPath("App_Data/Database.mdf") +"';Integrated Security=True";
        cn = new SqlConnection(strcn);
    }

    public DataTable getData(string query)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlDataAdapter da = new SqlDataAdapter(query, cn);
            da.Fill(dt);
        }catch (SqlException err) { Response.Write(err.Message); }
        return dt;
    }

    public void Update(string query)
    {
        try
        {
            SqlCommand command = new SqlCommand(query, cn);
            cn.Open();
            command.ExecuteNonQuery();
            cn.Close();
        }
        catch (SqlException err) { Response.Write(err.Message); }
    }
}